import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  
  section =['A','B','C'];
  


  public student = {
    name: " ",
    dept : " ",
    doj : " ",
    section : " "


  };//object
  
  lststudent = Array(); //array
  oldstudent = Array();
  constructor() { }

  ngOnInit() {
    this.oldstudent=JSON.parse(localStorage.getItem('student') || '{}');
    console.log(this.oldstudent);
  }
   
   onSubmit(data:any){ //function
    if(this.student){
      
      this.lststudent.push(this.student);
      localStorage.setItem('student',JSON.stringify(this.lststudent));
       console.log(this.student);
       this.student={
        name: " ",
        dept : " ",
        doj : " ",
        section : " "
    
  
       };

    }
   

   }
}
