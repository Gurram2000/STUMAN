import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display',
  
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.scss']
})
export class DisplayComponent implements OnInit {
lststudent = Array();

  constructor() { }

  ngOnInit(): void {
    this.lststudent=JSON.parse(localStorage.getItem('student') || '{}');
  }

  
 
  
}

